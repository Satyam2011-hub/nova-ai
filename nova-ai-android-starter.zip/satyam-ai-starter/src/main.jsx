import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  onAuthStateChanged, signInWithRedirect, getRedirectResult,
  signOut
} from "firebase/auth";
import {
  addDoc, collection, deleteDoc, doc, getDocs, onSnapshot,
  orderBy, query, serverTimestamp, setDoc
} from "firebase/firestore";
import { auth, googleProvider, db } from "./firebase";
import { Send, Plus, LogOut, MessageSquare, Trash2, Sparkles, Menu, X } from "lucide-react";
import "./style.css";

const API_URL = "PASTE_CLOUDFLARE_WORKER_URL";

function App() {
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [chats, setChats] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    getRedirectResult(auth).catch(() => setError("Google login failed. Check Firebase setup and authorized domains."));
    return onAuthStateChanged(auth, (u) => {
      setUser(u);
      setAuthReady(true);
    });
  }, []);

  useEffect(() => {
    if (!user) { setChats([]); setActiveId(null); setMessages([]); return; }
    const q = query(collection(db, "users", user.uid, "chats"), orderBy("updatedAt", "desc"));
    return onSnapshot(q, (snap) => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setChats(list);
      if (!activeId && list.length) setActiveId(list[0].id);
    }, () => setError("Could not load chat history. Check Firestore rules."));
  }, [user]);

  useEffect(() => {
    if (!user || !activeId) { setMessages([]); return; }
    const q = query(collection(db, "users", user.uid, "chats", activeId, "messages"), orderBy("createdAt", "asc"));
    return onSnapshot(q, snap => setMessages(snap.docs.map(d => ({ id: d.id, ...d.data() }))),
      () => setError("Could not load messages."));
  }, [user, activeId]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, busy]);

  async function login() {
    setError("");
    try { await signInWithRedirect(auth, googleProvider); }
    catch (e) { setError(e.message || "Could not start Google login."); }
  }

  async function newChat() {
    if (!user) return;
    const ref = doc(collection(db, "users", user.uid, "chats"));
    await setDoc(ref, { title: "New chat", createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
    setActiveId(ref.id);
    setMessages([]);
    setSidebarOpen(false);
    setError("");
  }

  async function removeChat(id) {
    if (!user || !confirm("Delete this chat and its messages?")) return;
    const snap = await getDocs(collection(db, "users", user.uid, "chats", id, "messages"));
    await Promise.all(snap.docs.map(d => deleteDoc(d.ref)));
    await deleteDoc(doc(db, "users", user.uid, "chats", id));
    if (activeId === id) { setActiveId(null); setMessages([]); }
  }

  async function sendMessage(e) {
    e?.preventDefault();
    const text = input.trim();
    if (!text || busy || !user) return;
    setError("");
    setInput("");
    setBusy(true);
    let chatId = activeId;
    try {
      if (!chatId) {
        const ref = doc(collection(db, "users", user.uid, "chats"));
        await setDoc(ref, { title: text.slice(0, 38), createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
        chatId = ref.id;
        setActiveId(chatId);
      }
      const msgCol = collection(db, "users", user.uid, "chats", chatId, "messages");
      await addDoc(msgCol, { role: "user", text, createdAt: serverTimestamp() });
      await setDoc(doc(db, "users", user.uid, "chats", chatId), {
        title: text.slice(0, 38), updatedAt: serverTimestamp()
      }, { merge: true });

      const token = await user.getIdToken();
      const response = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
        body: JSON.stringify({ message: text, history: messages.slice(-12).map(m => ({ role: m.role, text: m.text })) })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `AI request failed (${response.status}).`);
      await addDoc(msgCol, { role: "assistant", text: data.text || "I couldn't generate a response.", createdAt: serverTimestamp() });
      await setDoc(doc(db, "users", user.uid, "chats", chatId), { updatedAt: serverTimestamp() }, { merge: true });
    } catch (e) {
      setError(e.message || "Something went wrong. Check your API URL and internet.");
    } finally { setBusy(false); }
  }

  if (!authReady) return <div className="loading"><div className="orb"/><p>Getting things ready…</p></div>;

  if (!user) return (
    <main className="login-screen">
      <div className="login-card">
        <div className="brand-mark"><Sparkles size={26}/></div>
        <h1>Meet Nova AI</h1>
        <p>Your ideas, questions and learning — in one place.</p>
        <button className="google-btn" onClick={login}><span className="google-g">G</span> Continue with Google</button>
        {error && <p className="error">{error}</p>}
        <small>Sign in once. Your chat history stays linked to your account.</small>
      </div>
    </main>
  );

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
        <div className="side-top">
          <div className="brand"><span className="brand-mark small"><Sparkles size={18}/></span><b>Nova AI</b></div>
          <button className="icon-btn mobile-close" onClick={() => setSidebarOpen(false)} aria-label="Close menu"><X/></button>
        </div>
        <button className="new-chat" onClick={newChat}><Plus size={18}/> New chat</button>
        <p className="side-label">RECENT</p>
        <div className="chat-list">
          {chats.map(chat => <div key={chat.id} className={`chat-row ${activeId === chat.id ? "selected" : ""}`}>
            <button className="chat-pick" onClick={() => { setActiveId(chat.id); setSidebarOpen(false); setError(""); }}>
              <MessageSquare size={16}/><span>{chat.title || "New chat"}</span>
            </button>
            <button className="delete-btn" onClick={() => removeChat(chat.id)} aria-label="Delete chat"><Trash2 size={14}/></button>
          </div>)}
          {!chats.length && <p className="empty-side">Your chats will appear here.</p>}
        </div>
        <div className="profile">
          {user.photoURL ? <img src={user.photoURL} alt="" /> : <div className="avatar">{(user.displayName || "U")[0]}</div>}
          <div className="profile-text"><b>{user.displayName || "User"}</b><small>{user.email}</small></div>
          <button className="icon-btn" onClick={() => signOut(auth)} aria-label="Sign out"><LogOut size={17}/></button>
        </div>
      </aside>
      {sidebarOpen && <button className="scrim" onClick={() => setSidebarOpen(false)} aria-label="Close sidebar"/>}
      <main className="main">
        <header className="topbar">
          <button className="icon-btn menu-btn" onClick={() => setSidebarOpen(true)} aria-label="Open menu"><Menu/></button>
          <span className="top-title">Nova AI</span>
          <span className="online-dot" title="Ready"/>
        </header>
        <section className={`conversation ${messages.length ? "has-messages" : ""}`}>
          {!messages.length && !busy && <div className="welcome">
            <div className="welcome-icon"><Sparkles size={25}/></div>
            <h2>What can I help you with?</h2>
            <p>Ask a question, learn something new, or work through an idea.</p>
            <div className="suggestions">
              {["Explain a topic simply","Help me write something","Give me a coding example"].map(s =>
                <button key={s} onClick={() => setInput(s)}>{s}<span>↗</span></button>)}
            </div>
          </div>}
          <div className="message-stack">
            {messages.map(m => <div key={m.id} className={`message ${m.role}`}>
              {m.role === "assistant" && <div className="assistant-icon"><Sparkles size={15}/></div>}
              <div className="bubble">{m.text}</div>
            </div>)}
            {busy && <div className="message assistant"><div className="assistant-icon"><Sparkles size={15}/></div><div className="bubble typing"><i/><i/><i/></div></div>}
            <div ref={bottomRef}/>
          </div>
        </section>
        <div className="composer-wrap">
          {error && <div className="error banner">{error}</div>}
          <form className="composer" onSubmit={sendMessage}>
            <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => {
              if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
            }} placeholder="Message Nova AI…" rows="1" />
            <button className="send-btn" type="submit" disabled={!input.trim() || busy} aria-label="Send message"><Send size={18}/></button>
          </form>
          <p className="disclaimer">AI can make mistakes. Check important information.</p>
        </div>
      </main>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
