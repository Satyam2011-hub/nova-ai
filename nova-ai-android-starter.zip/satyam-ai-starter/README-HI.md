# Nova AI — Android phone se setup (starter project)

Ye project ek installable web app/PWA hai. Android Chrome se install ho sakta hai aur app jaisa open hota hai. Ye abhi signed APK nahi hai. Pehle working login + AI + history banayenge; baad mein APK package kiya ja sakta hai.

## Kya milega
- Firebase Google login
- Firestore mein account-wise chats/messages
- Gemini API call ek Cloudflare Worker ke through
- Worker Firebase ID token verify karta hai; Gemini API key browser code mein nahi hai
- Responsive white interface

## Step 1 — Firebase project
1. Firebase Console kholo: https://console.firebase.google.com/
2. New project banao.
3. Project settings → General → Your apps → Web app add karo.
4. Firebase web config ke `apiKey`, `authDomain`, `projectId`, `appId` values `src/firebase.js` mein placeholders ki jagah paste karo. Firebase web config public identifier hota hai; Firestore rules zaroor lagao.
5. Authentication → Sign-in method → Google enable karo.
6. Firestore Database create karo.
7. Firestore Rules mein root folder ka `firestore.rules` content publish karo.
8. Authentication → Settings → Authorized domains mein deployed app ka domain add karo.

## Step 2 — Gemini API key
1. Google AI Studio kholo: https://aistudio.google.com/
2. API key create karo. Free tier ke model/usage limits badal sakte hain; API key ko public source code, screenshots ya chat mein share mat karna.
3. Is key ko sirf Cloudflare Worker secret mein save karna hai, `src/` mein nahi.

## Step 3 — Cloudflare Worker (AI backend)
Worker deploy karne ke liye Cloudflare account aur Wrangler CLI deployment environment chahiye. Phone par Cloudflare dashboard/online editor use kar sakte ho, lekin dependency install/deploy ke liye kisi terminal-enabled coding workspace ki zaroorat pad sakti hai.

1. `worker/` ke files ko ek Worker project mein rakho.
2. `worker/wrangler.toml` mein `FIREBASE_PROJECT_ID` ko Firebase project ID se replace karo.
3. `ALLOWED_ORIGIN` ko deployed frontend ka exact origin banao, jaise `https://your-app.pages.dev` (last slash ke bina).
4. Worker secret set karo: `GEMINI_API_KEY` = tumhari AI Studio key. Isse normal variable ya frontend code mein mat rakho.
5. Worker deploy karo; uska URL note karo.
6. `src/main.jsx` mein `API_URL` ko Worker URL se replace karo.

Typical CLI commands (terminal access ho to):
```bash
cd worker
npm install
npx wrangler secret put GEMINI_API_KEY
npx wrangler deploy
```
`wrangler secret put` chalane par key terminal prompt mein paste karo, code file mein nahi.

## Step 4 — Frontend deploy
1. Project ko GitHub repo mein upload karo.
2. Cloudflare Pages (ya koi Vite-compatible static host) se repo connect karo.
3. Build command: `npm run build`
4. Build output directory: `dist`
5. Deploy hone ke baad final site URL ko Worker ke `ALLOWED_ORIGIN` aur Firebase Authorized domains mein set karo. Agar origin badlo to Worker redeploy karo.
6. Local test ke liye `npm install` phir `npm run dev`.

## Step 5 — Android par install
1. Deployed site ko Android Chrome mein kholo.
2. Chrome menu (⋮) → Add to Home screen / Install app.
3. Home screen par icon se app open karo.

## Troubleshooting
- `auth/unauthorized-domain`: deployed domain Firebase Auth → Authorized domains mein add karo.
- Google login loop: Firebase config aur `authDomain` dobara check karo.
- AI 401: Worker `FIREBASE_PROJECT_ID` Firebase project ID se exact match hona chahiye.
- AI 403: Worker ka `ALLOWED_ORIGIN` app URL se exact match hona chahiye.
- AI 429: free quota/rate limit hit hua ho sakta hai; thodi der baad retry karo.
- AI 502: Worker secret `GEMINI_API_KEY` aur model availability check karo.
- Chat history load nahi: Firestore rules publish kiye hain aur correct Firebase project use ho raha hai, check karo.

## Important
- Ye starter project hai, audited production service nahi. Public launch se pehle per-user rate limits, abuse protection, privacy notice, error logging aur stronger backend controls add karo.
- Free-tier limits can change. Never promise unlimited free AI responses.
- Firestore rules ensure users can read/write only their own `/users/{uid}/...` data.
- Don't commit API keys, passwords, service-account files or private tokens to GitHub.
