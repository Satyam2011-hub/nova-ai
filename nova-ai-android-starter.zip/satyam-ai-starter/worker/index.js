import { createRemoteJWKSet, jwtVerify } from "jose";

const jwks = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com")
);

function cors(origin, allowed) {
  const ok = origin === allowed;
  return {
    "Access-Control-Allow-Origin": ok ? origin : allowed,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Vary": "Origin"
  };
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    const headers = cors(origin, env.ALLOWED_ORIGIN);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
    const reply = (data, status = 200) => new Response(JSON.stringify(data), {
      status, headers: { ...headers, "Content-Type": "application/json" }
    });
    if (origin !== env.ALLOWED_ORIGIN) return reply({ error: "Origin not allowed." }, 403);
    if (request.method !== "POST") return reply({ error: "Use POST." }, 405);

    try {
      const authHeader = request.headers.get("Authorization") || "";
      if (!authHeader.startsWith("Bearer ")) return reply({ error: "Please sign in first." }, 401);
      const token = authHeader.slice(7);
      const { payload } = await jwtVerify(token, jwks, {
        issuer: `https://securetoken.google.com/${env.FIREBASE_PROJECT_ID}`,
        audience: env.FIREBASE_PROJECT_ID
      });
      if (!payload.sub) return reply({ error: "Invalid user token." }, 401);

      const body = await request.json();
      const message = String(body.message || "").trim();
      if (!message) return reply({ error: "Message is empty." }, 400);
      if (message.length > 8000) return reply({ error: "Please keep each message under 8,000 characters." }, 400);

      const history = Array.isArray(body.history) ? body.history.slice(-12) : [];
      const contents = [];
      for (const item of history) {
        if (!item || !["user", "assistant"].includes(item.role) || typeof item.text !== "string") continue;
        contents.push({
          role: item.role === "assistant" ? "model" : "user",
          parts: [{ text: item.text.slice(0, 8000) }]
        });
      }
      contents.push({ role: "user", parts: [{ text: message }] });

      const upstream = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${env.GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents,
            generationConfig: { temperature: 0.7, maxOutputTokens: 1200 }
          })
        }
      );
      const result = await upstream.json();
      if (!upstream.ok) {
        return reply({ error: result?.error?.message || "AI provider request failed. Check API key and free quota." }, upstream.status === 429 ? 429 : 502);
      }
      const answer = result?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
      if (!answer) return reply({ error: "The AI did not return a text answer. Try again." }, 502);
      return reply({ text: answer });
    } catch (err) {
      return reply({ error: "Request failed. Check sign-in token, project settings, and API configuration." }, 401);
    }
  }
};
